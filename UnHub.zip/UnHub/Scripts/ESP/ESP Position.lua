local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local LocalPlayer = Players.LocalPlayer
local EspName = "EP"

local CharacterConnections = {}
local NewPlayers = {}
local RenderConnections = {}
local PlayerAddedConnection = nil

local RunEspPosition = {}

function CreateEspPosition(player, Color)
	if not player.Character then return end
	local head = player.Character:FindFirstChild("Head")
	local hrp = player.Character:FindFirstChild("HumanoidRootPart")
	if not head or not hrp then return end

	local oldGui = head:FindFirstChild(EspName)
	if oldGui then oldGui:Destroy() end

	local BillboardGui = Instance.new("BillboardGui")
	BillboardGui.Name = EspName
	BillboardGui.Size = UDim2.new(0, 200, 0, 30)
	BillboardGui.Adornee = head
	BillboardGui.AlwaysOnTop = true
	BillboardGui.Parent = head

	local Label = Instance.new("TextLabel")
	Label.Size = UDim2.new(1, 0, 1, 0)
	Label.BackgroundTransparency = 1
	Label.TextColor3 = Color
	Label.TextStrokeTransparency = 0.5
	Label.TextStrokeColor3 = Color3.new(0, 0, 0)
	Label.Font = Enum.Font.SourceSansBold
	Label.TextSize = 14
	Label.TextScaled = true
	Label.Parent = BillboardGui

	if RenderConnections[player] then
		RenderConnections[player]:Disconnect()
	end

	RenderConnections[player] = RunService.RenderStepped:Connect(function()
		if hrp and hrp.Parent then
			local pos = hrp.Position
			Label.Text = string.format("X: %d Y: %d Z: %d", pos.X, pos.Y, pos.Z)
		else
			Label.Text = "X: 0 Y: 0 Z: 0"
		end
	end)
end

function RunEspPosition:On(Color)
	for _, player in pairs(Players:GetPlayers()) do
		if player ~= LocalPlayer then
			CreateEspPosition(player, Color)

			if CharacterConnections[player] then
				CharacterConnections[player]:Disconnect()
			end

			CharacterConnections[player] = player.CharacterAdded:Connect(function()
				task.wait(1)
				CreateEspPosition(player, Color)
			end)
		end
	end

	PlayerAddedConnection = Players.PlayerAdded:Connect(function(plr)
		NewPlayers[plr] = plr.CharacterAdded:Connect(function()
			task.wait(1)
			CreateEspPosition(plr, Color)
		end)
	end)
end

function RunEspPosition:Off()
	for _, player in pairs(Players:GetPlayers()) do
		local character = player.Character
		if character and character:FindFirstChild("Head") then
			local head = character.Head
			local esp = head:FindFirstChild(EspName)
			if esp then
				esp:Destroy()
			end
		end

		if CharacterConnections[player] then
			CharacterConnections[player]:Disconnect()
			CharacterConnections[player] = nil
		end

		if RenderConnections[player] then
			RenderConnections[player]:Disconnect()
			RenderConnections[player] = nil
		end
	end

	for plr, conn in pairs(NewPlayers) do
		if conn then conn:Disconnect() end
		NewPlayers[plr] = nil
	end

	if PlayerAddedConnection then
		PlayerAddedConnection:Disconnect()
		PlayerAddedConnection = nil
	end
end

return RunEspPosition