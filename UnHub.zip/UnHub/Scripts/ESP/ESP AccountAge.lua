local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer
local EspName = "EA"

local CharacterConnections = {}
local NewPlayers = {}
local PlayerAddedConnection = nil

local RunEspDisplayName = {}

function CreateEspDisplayName(player, Color)
	if not player.Character then return end
	local head = player.Character:FindFirstChild("Head")
	if not head then return end

	-- Remove old ESP if exists
	local oldGui = head:FindFirstChild(EspName)
	if oldGui then oldGui:Destroy() end

	-- Create BillboardGui
	local BillboardGui = Instance.new("BillboardGui")
	BillboardGui.Name = EspName
	BillboardGui.Size = UDim2.new(0, 150, 0, 30)
	BillboardGui.Adornee = head
	BillboardGui.AlwaysOnTop = true
	BillboardGui.Parent = head

	-- Create TextLabel
	local Label = Instance.new("TextLabel")
	Label.Size = UDim2.new(1, 0, 1, 0)
	Label.BackgroundTransparency = 1
	Label.TextColor3 = Color
	Label.TextStrokeTransparency = 0.5
	Label.TextStrokeColor3 = Color3.new(0, 0, 0)
	Label.Font = Enum.Font.SourceSansBold
	Label.TextSize = 14
	Label.TextScaled = true
	Label.Text = player.AccountAge -- <-- Show display name
	Label.Parent = BillboardGui
end

function RunEspDisplayName:On(Color)
	for _, player in pairs(Players:GetPlayers()) do
		if player ~= LocalPlayer then
			CreateEspDisplayName(player, Color)

			if CharacterConnections[player] then
				CharacterConnections[player]:Disconnect()
			end

			CharacterConnections[player] = player.CharacterAdded:Connect(function()
				task.wait(1)
				CreateEspDisplayName(player, Color)
			end)
		end
	end

	PlayerAddedConnection = Players.PlayerAdded:Connect(function(plr)
		NewPlayers[plr] = plr.CharacterAdded:Connect(function()
			task.wait(1)
			CreateEspDisplayName(plr, Color)
		end)
	end)
end

function RunEspDisplayName:Off()
	for _, player in pairs(Players:GetPlayers()) do
		local character = player.Character
		if character and character:FindFirstChild("Head") then
			local head = character.Head
			local esp = head:FindFirstChild(EspName)
			if esp then
				esp:Destroy()
			end
		end

		if CharacterConnections[player] then
			CharacterConnections[player]:Disconnect()
			CharacterConnections[player] = nil
		end
	end

	for plr, conn in pairs(NewPlayers) do
		if conn then conn:Disconnect() end
		NewPlayers[plr] = nil
	end

	if PlayerAddedConnection then
		PlayerAddedConnection:Disconnect()
		PlayerAddedConnection = nil
	end
end

return RunEspDisplayName