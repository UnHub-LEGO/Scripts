local Players = game:GetService("Players")

local player = Players.LocalPlayer
local mouse = player:GetMouse()

local tool = Instance.new("Tool")
tool.RequiresHandle = false
tool.Name = "Position Tool"
tool.Parent = player.Backpack

tool.Activated:Connect(function()
    print(mouse.Hit.Position)
end)