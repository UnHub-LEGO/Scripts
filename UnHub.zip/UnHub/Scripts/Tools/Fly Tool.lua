local tpHero, flyingHero, flyHero = false, false, false
local speedsHero = 5
local notMoving = false
local loadanim
local heartbeatConnection = nil
local flyMoveConn = nil
local plr = game.Players.LocalPlayer
local Camera = game.Workspace.Camera
local R6
local test = 0
local anim

local function PlayAnim(id, time, speed)
    local chr = plr.Character
    local hum = chr and chr:FindFirstChildWhichIsA("Humanoid")
    pcall(function()
        chr.Animate.Disabled = false
        for _, track in pairs(hum:GetPlayingAnimationTracks()) do
            track:Stop()
        end
        chr.Animate.Disabled = true
        local anim = Instance.new("Animation")
        anim.AnimationId = "rbxassetid://" .. id
        loadanim = hum:LoadAnimation(anim)
        loadanim:Play(2, 5, 10)
        loadanim.TimePosition = time
        loadanim:AdjustSpeed(speed)
        loadanim.Stopped:Connect(function()
            chr.Animate.Disabled = false
        end)
    end)
end

function FlyHero()
    local chr = plr.Character
    local hum = chr and chr:FindFirstChildWhichIsA("Humanoid")
    if not chr or not hum then return end
    
    notMoving = true
    flyHero, flyingHero, tpHero = true, true, true

    local Torso = chr:FindFirstChild("UpperTorso") or chr:FindFirstChild("Torso")
    
    local flyBV = Instance.new("BodyVelocity", Torso)
    flyBV.Velocity = Vector3.new(0, 0.1, 0)
    flyBV.MaxForce = Vector3.new(9e9, 9e9, 9e9)
    flyBV.Name = "flyBVHero"
    
	task.spawn(function()
		while flyHero do
			flyBV.Velocity = Vector3.new(0, 2, 0)
			task.wait(1)
			flyBV.Velocity = Vector3.new(0, -2, 0)
			task.wait(1)
		end
	end)

    local bg = Instance.new("BodyGyro", Torso)
    bg.P = 9999
    bg.MaxTorque = Vector3.new(509, 509, 509)
    bg.CFrame = Torso.CFrame
    
    chr.Animate.Disabled = true
    
    if hum.RigType == Enum.HumanoidRigType.R6 then
        PlayAnim(429730430, 4.95, 0)
        anim = game:GetService("RunService").Heartbeat:Connect(function()
        	if tpHero and hum then
        		local moving = hum.MoveDirection.Magnitude > 0
        		if moving and notMoving then
        			notMoving = false
for _, track in pairs(hum:GetPlayingAnimationTracks()) do
        track:Stop()
    end
wait()
        			PlayAnim(90872539, 1, 0)
        			local bg = Torso:FindFirstChildOfClass("BodyGyro")
        			if bg then bg:Destroy() end
        			local TweenService = game:GetService("TweenService")  
                	TweenService:Create(Camera, TweenInfo.new(0.5), {FieldOfView = 110}):Play()  
        		elseif not moving and not notMoving then
        			notMoving = true
for _, track in pairs(hum:GetPlayingAnimationTracks()) do
        track:Stop()
    end
wait()
        			PlayAnim(429730430, 4.95, 0)
        			local TweenService = game:GetService("TweenService")  
                	TweenService:Create(Camera, TweenInfo.new(0.5), {FieldOfView = 70}):Play()  
        		end
        	end
        end)
    elseif hum.RigType == Enum.HumanoidRigType.R15 then
        PlayAnim(10714347256, 4.65, 0)
        anim = game:GetService("RunService").Heartbeat:Connect(function()
        	if tpHero and hum then
        		local moving = hum.MoveDirection.Magnitude > 0
        		if moving and notMoving then
        			notMoving = false
for _, track in pairs(hum:GetPlayingAnimationTracks()) do
        track:Stop()
    end
wait()
        			PlayAnim(10714177846, 4.65, 0)
        			local bg = Torso:FindFirstChildOfClass("BodyGyro")
        			if bg then bg:Destroy() end
        			local TweenService = game:GetService("TweenService")  
                	TweenService:Create(Camera, TweenInfo.new(0.5), {FieldOfView = 110}):Play()  
        		elseif not moving and not notMoving then
        			notMoving = true
for _, track in pairs(hum:GetPlayingAnimationTracks()) do
        track:Stop()
    end
wait()
        			PlayAnim(10714347256, 4.65, 0)
        			local TweenService = game:GetService("TweenService")  
                	TweenService:Create(Camera, TweenInfo.new(0.5), {FieldOfView = 70}):Play()  
        		end
        	end
        end)
    end
    flyMoveConn = game:GetService("RunService").Heartbeat:Connect(function()
        if tpHero and hum then
            if hum.MoveDirection.Magnitude > 0 then
            	chr:TranslateBy(hum.MoveDirection * speedsHero * 0.3)
            end
        end
    end)
    
    for _, track in pairs(hum:GetPlayingAnimationTracks()) do
        track:AdjustSpeed(0)
    end
    
    for _, state in pairs(Enum.HumanoidStateType:GetEnumItems()) do
        pcall(function() hum:SetStateEnabled(state, false) end)
    end

    hum:SetStateEnabled(Enum.HumanoidStateType.Flying, true)
    hum:ChangeState(Enum.HumanoidStateType.Swimming)
    
    heartbeatConnection = game:GetService("RunService").Heartbeat:Connect(function()
        if notMoving and flyingHero then
            local Torso = chr:FindFirstChild("UpperTorso") or chr:FindFirstChild("Torso")
            if not Torso then return end
            local currentBG = Torso:FindFirstChildOfClass("BodyGyro")
            if not currentBG then
                currentBG = Instance.new("BodyGyro")
                currentBG.P = 9999
                currentBG.MaxTorque = Vector3.new(5e9, 5e9, 5e9)
                currentBG.CFrame = Torso.CFrame
                currentBG.Parent = Torso
            end
            
            currentBG.CFrame = Camera.CFrame
        end
    end)
end

function unFlyHero()
    local TweenService = game:GetService("TweenService")  
    TweenService:Create(Camera, TweenInfo.new(0.5), {FieldOfView = 70}):Play()  
    if heartbeatConnection then
        heartbeatConnection:Disconnect()
        heartbeatConnection = nil
    end
    if flyMoveConn then
        flyMoveConn:Disconnect()
        flyMoveConn = nil
    end
    if anim then
        anim:Disconnect()
        anim = nil
    end
    notMoving = false
    wait()
    if loadanim then loadanim:Stop() end
    flyHero, flyingHero, tpHero = false, false, false

    local chr = plr.Character
    if not chr then return end
    local hum = chr:FindFirstChildWhichIsA("Humanoid")
    local Torso = chr:FindFirstChild("UpperTorso") or chr:FindFirstChild("Torso")

    if hum then
        for _, state in pairs(Enum.HumanoidStateType:GetEnumItems()) do
            pcall(function() hum:SetStateEnabled(state, true) end)
        end
        hum:ChangeState(Enum.HumanoidStateType.Running)
    end

    if Torso then
        wait()
        local bv = Torso:FindFirstChild("flyBVHero")
        if bv then bv:Destroy() end
        local bg = Torso:FindFirstChildOfClass("BodyGyro")
        if bg then bg:Destroy() end
        local a = Torso:FindFirstChild("A")
        if a then a:Destroy() end
    end

    local animateScript = chr:FindFirstChild("Animate")
    if animateScript then
        animateScript.Disabled = false
    end
end

function updata()
    local chr = plr.Character
    local hum = chr:FindFirstChildWhichIsA("Humanoid")
    if flyMoveConn then
        flyMoveConn:Disconnect()
        flyMoveConn = nil
    end

    flyMoveConn = game:GetService("RunService").Heartbeat:Connect(function()
        if chr and hum then
            chr:TranslateBy(hum.MoveDirection * speedsHero * 0.3)
        end
    end)
end

plr.Character:WaitForChild("Humanoid").Died:Connect(function()
    if flyHero then unFlyHero() end
end)

local toggle = true
local player = game.Players.LocalPlayer.Character.Humanoid
tool = Instance.new("Tool")
tool.RequiresHandle = false
tool.Name = "Fly Disabled"
tool.Equipped:Connect(function()
    local Tool
    for i, v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
        if v:IsA("Tool") and v.Name == tool.Name then
            Tool = v
        end
    end
if toggle then
toggle = false
Tool.Name = "Fly Enable"
task.wait()
Tool.Parent = game.Players.LocalPlayer.Backpack
FlyHero()
else
toggle = true
Tool.Name = "Fly Disabled"
task.wait()
Tool.Parent = game.Players.LocalPlayer.Backpack
unFlyHero()
end
end)
tool.Parent = game.Players.LocalPlayer.Backpack