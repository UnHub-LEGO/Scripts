local tpHero, flyingHero, flyHero = false, false, false

local speeds = 1

local notMoving = false

local loadanim

local heartbeatConnection = nil

local flyMoveConn = nil

local plr = game.Players.LocalPlayer

local anim

local function PlayAnim(id, time, speed)

    local chr = plr.Character

    local hum = chr and chr:FindFirstChildWhichIsA("Humanoid")

    pcall(function()

        chr.Animate.Disabled = false

        for _, track in pairs(hum:GetPlayingAnimationTracks()) do

            track:Stop()

        end

        chr.Animate.Disabled = true

        local anim = Instance.new("Animation")

        anim.AnimationId = "rbxassetid://" .. id

        loadanim = hum:LoadAnimation(anim)

        loadanim:Play()

        loadanim.TimePosition = time

        loadanim:AdjustSpeed(speed)

        loadanim.Stopped:Connect(function()

            chr.Animate.Disabled = false

        end)

    end)

end

function FlyHero()

    local chr = plr.Character

    local hum = chr and chr:FindFirstChildWhichIsA("Humanoid")

    if not chr or not hum then return end

    

    notMoving = true

    flyHero, flyingHero, tpHero = true, true, true

    local Torso = chr:FindFirstChild("UpperTorso") or chr:FindFirstChild("Torso")

    

    local flyBV = Instance.new("BodyVelocity", Torso)

    flyBV.Velocity = Vector3.new(0, 0.1, 0)

    flyBV.MaxForce = Vector3.new(9e9, 9e9, 9e9)

    flyBV.Name = "flyBVHero"

    

    chr.Animate.Disabled = true

    for _, track in pairs(hum:GetPlayingAnimationTracks()) do

        track:AdjustSpeed(0)

    end

    if hum.RigType == Enum.HumanoidRigType.R6 then

        PlayAnim(180426354, 0.1, 0.3)

        anim = game:GetService("RunService").Heartbeat:Connect(function()

        	if tpHero and hum then        		local moving = hum.MoveDirection.Magnitude > 0

        		if moving and notMoving then

        			notMoving = false

        			PlayAnim(180426354, 0.1, 1)

        		elseif not moving and not notMoving then

        			notMoving = true

        			PlayAnim(180426354, 0.1, 0.3)

        		end

        	end

        end)

    elseif hum.RigType == Enum.HumanoidRigType.R15 then

        PlayAnim(913389285, 0.1, 1)

        anim = game:GetService("RunService").Heartbeat:Connect(function()

        	if tpHero and hum then

        		local moving = hum.MoveDirection.Magnitude > 0

        		if moving and notMoving then

        			notMoving = false

        			PlayAnim(913384386, 0.1, 1)

        		elseif not moving and not notMoving then

        			notMoving = true

        			PlayAnim(913389285, 0.1, 1)

        		end

        	end

        end)

end

game:GetService("RunService").Heartbeat:Connect(function()

        if tpHero and hum then

            if hum.MoveDirection.Magnitude > 0 then

            	chr:TranslateBy(hum.MoveDirection * speeds * 0.3)

            end

        end

    end)

    

    for _, state in pairs(Enum.HumanoidStateType:GetEnumItems()) do

        pcall(function() hum:SetStateEnabled(state, false) end)

    end

    hum:SetStateEnabled(Enum.HumanoidStateType.Flying, true)

    hum:ChangeState(Enum.HumanoidStateType.Swimming)

end

function unFlyHero()

    if flyMoveConn then

        flyMoveConn:Disconnect()

        flyMoveConn = nil

    end

    if anim then

        anim:Disconnect()

        anim = nil

    end

    notMoving = false

    wait()

    if loadanim then loadanim:Stop() end

    flyHero, flyingHero, tpHero = false, false, false

    local chr = plr.Character

    if not chr then return end

    local hum = chr:FindFirstChildWhichIsA("Humanoid")

    local Torso = chr:FindFirstChild("UpperTorso") or chr:FindFirstChild("Torso")

    if hum then

        for _, state in pairs(Enum.HumanoidStateType:GetEnumItems()) do

            pcall(function() hum:SetStateEnabled(state, true) end)

        end

        hum:ChangeState(Enum.HumanoidStateType.Running)

    end

    if Torso then

        wait()

        local bv = Torso:FindFirstChild("flyBVHero")

        if bv then bv:Destroy() end

    end

    local animateScript = chr:FindFirstChild("Animate")

    if animateScript then

        animateScript.Disabled = false

    end

end

plr.Character:WaitForChild("Humanoid").Died:Connect(function()

    if flyHero then unFlyHero() end

end)

local toggle = true

local player = game.Players.LocalPlayer.Character.Humanoid

tool = Instance.new("Tool")

tool.RequiresHandle = false

tool.Name = "Swim Disabled"

tool.Equipped:Connect(function()
local Tool
    for i, v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
        if v:IsA("Tool") and v.Name == tool.Name then
            Tool = v
        end
    end
if toggle then

toggle = false

Tool.Name = "Swim Enable"

task.wait()

Tool.Parent = game.Players.LocalPlayer.Backpack

FlyHero()

else

toggle = true

Tool.Name = "Swim Disabled"

task.wait()

Tool.Parent = game.Players.LocalPlayer.Backpack

unFlyHero()

end

end)

tool.Parent = game.Players.LocalPlayer.Backpack