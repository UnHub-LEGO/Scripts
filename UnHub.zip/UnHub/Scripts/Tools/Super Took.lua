local plr = game.Players.LocalPlayer
local toggle = true

local player = game.Players.LocalPlayer.Character.Humanoid
tool = Instance.new("Tool")
tool.RequiresHandle = false
tool.Name = "Super Disabled"
tool.Equipped:Connect(function()
toggle = not toggle
	if toggle then
		tool.Name = "Super Disabled"
		player.WalkSpeed = 16
		player.JumpPower = 50
		tool.Parent = game.Players.LocalPlayer.Backpack
	else
		tool.Name = "Super Enabled"
		player.WalkSpeed = 64
		player.JumpPower = 150
		tool.Parent = game.Players.LocalPlayer.Backpack
	end
end)

tool.Parent = game.Players.LocalPlayer.Backpack