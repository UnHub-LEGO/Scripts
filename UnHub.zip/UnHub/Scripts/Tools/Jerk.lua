local plr = game.Players.LocalPlayer
local hum = plr.Character.Humanoid

if hum.RigType == Enum.HumanoidRigType.R6 then
loadstring(game:HttpGet("https://pastefy.app/wa3v2Vgm/raw"))()
plr.CharacterAdded:Connect(function(chr)
wait(0.5)
if plr.Backpack:FindFirstChild("Jerk Off") then
plr.Backpack:WaitForChild("Jerk Off"):Destroy()
end
end)
else
loadstring(game:HttpGet("https://pastefy.app/YZoglOyJ/raw"))()
plr.Backpack:FindFirstChild("Jerk Off R15").Name = "Jerk Off"
plr.CharacterAdded:Connect(function(chr)
wait(0.5)
if plr.Backpack:FindFirstChild("Jerk Off R15") then
plr.Backpack:WaitForChild("Jerk Off R15"):Destroy()
end
end)
end