local Players = game:GetService("Players")

local player = Players.LocalPlayer
local mouse = player:GetMouse()

local tool = Instance.new("Tool")
tool.RequiresHandle = false
tool.Name = "Block Tool"
tool.Parent = player.Backpack

tool.Activated:Connect(function()
    local Block = Instance.new("Part")
    Block.Size = Vector3.new(4, 4, 4)
    Block.Parent = workspace
    Block.Position = mouse.Hit.Position + Vector3.new(0, 3, 0)
end)