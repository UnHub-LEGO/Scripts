local Players = game:GetService("Players")

local LocalPlayer = Players.LocalPlayer

local chr = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()

local hum = chr:WaitForChild("Humanoid")

local hrp = chr:WaitForChild("HumanoidRootPart")

local toggle = false

local tool = Instance.new("Tool")

tool.RequiresHandle = false

tool.Name = "Lag Disable"

tool.Parent = LocalPlayer.Backpack

tool.Equipped:Connect(function()
local Tool
    for i, v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
        if v:IsA("Tool") and v.Name == tool.Name then
            Tool = v
        end
    end
	toggle = not toggle	Tool.Name = toggle and "Lag Enable" or "Lag Disable"

	wait()

	Tool.Parent = LocalPlayer.Backpack

end)

task.spawn(function()

	while true do

		if toggle then

			for _, player in ipairs(Players:GetPlayers()) do

				if player ~= LocalPlayer then -- skip self

					local char = player.Character

					if char then

						local h = char:FindFirstChild("Humanoid")

						local hrp = char:FindFirstChild("HumanoidRootPart")

						if hrp then hrp.Anchored = true end

						if h then

							for _, track in ipairs(h:GetPlayingAnimationTracks()) do

								track:AdjustSpeed(0)

							end

						end

					end

				end

			end

			task.wait(0.4)

			for _, player in ipairs(Players:GetPlayers()) do

				if player ~= LocalPlayer then -- skip self

					local char = player.Character

					if char then

						local h = char:FindFirstChild("Humanoid")

						local hrp = char:FindFirstChild("HumanoidRootPart")

						if hrp then hrp.Anchored = false end

						if h then

							for _, track in ipairs(h:GetPlayingAnimationTracks()) do

								track:AdjustSpeed(1)

							end

						end

					end

				end

			end

		end

		task.wait(0.5)

	end

end)