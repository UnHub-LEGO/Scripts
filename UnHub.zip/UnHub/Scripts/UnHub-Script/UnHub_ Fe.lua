local Library = loadstring(game:HttpGet("https://raw.githubusercontent.com/NICKISBAD/Nick-s-Modded-KAVO-Lib/main/Nick'sModdedKavoLib.lua"))()
local Window = Library.CreateLib("Un Hub: Fe | Make by LE_GO89", "DarkTheme")
local player = game.Players.LocalPlayer
local animator
local animTrack
local id
local speed = 1
local isPlaying = false
local RunService = game:GetService("RunService")
local tracks = {}
local connections = {}

local Tab = Window:NewTab("Fe Animation")
local Section = Tab:NewSection("Fe Animation")

local function Walk(id)
local animate = game.Players.LocalPlayer.Character:WaitForChild("Animate")
animate.walk.WalkAnim.AnimationId = "rbxassetid://" ..id
end

local function Run(id)
local animate = game.Players.LocalPlayer.Character:WaitForChild("Animate")
animate.run.RunAnim.AnimationId = "rbxassetid://" ..id
end

local function Jump(id)
local animate = game.Players.LocalPlayer.Character:WaitForChild("Animate")
animate.jump.JumpAnim.AnimationId = "rbxassetid://" ..id
end

local function Climb(id)
local animate = game.Players.LocalPlayer.Character:WaitForChild("Animate")
animate.climb.ClimbAnim.AnimationId = "rbxassetid://" ..id
end

local function fall(id)
local animate = game.Players.LocalPlayer.Character:WaitForChild("Animate")
animate.fall.FallAnim.AnimationId = "rbxassetid://" ..id
end

local function Swim(id1, id2)
local animate = game.Players.LocalPlayer.Character:WaitForChild("Animate")
animate.swim.Swim.AnimationId = "rbxassetid://" ..id2
animate.swimidle.SwimIdle.AnimationId = "rbxassetid://" ..id1
end

local function Idle(id1, id2)
local animate = game.Players.LocalPlayer.Character:WaitForChild("Animate")
animate.idle.Animation1.AnimationId = "rbxassetid://" ..id1
animate.idle.Animation2.AnimationId = "rbxassetid://" ..id2
end

local animations = {
walk = {
{Name = "Astronaut", Id = "891667138"},
{Name = "Adidas Community", Id = "122150855457006"},
{Name = "Bold", Id = "16738340646"},
{Name = "Bubbly", Id = "910034870"},
{Name = "Cartoony", Id = "742640026"},
{Name = "Confident", Id = "1070017263"},
{Name = "Cowboy", Id = "1014421541"},
{Name = "Catwalk Glam", Id = "109168724482748"},
{Name = "Drooling Zombie", Id = "3489174223"},
{Name = "Elder", Id = "10921111375"},
{Name = "Ghost", Id = "616013216"},
{Name = "Knight", Id = "10921127095"},
{Name = "Levitation", Id = "616013216"},
{Name = "Mage", Id = "707897309"},
{Name = "Ninja", Id = "656121766"},
{Name = "NFL", Id = "110358958299415"},
{Name = "OldSchool", Id = "10921244891"},
{Name = "Patrol", Id = "1151231493"},
{Name = "Pirate", Id = "750785693"},
{Name = "Default Retarget", Id = "115825677624788"},
{Name = "Popstar", Id = "1212980338"},
{Name = "Princess", Id = "941028902"},
{Name = "R6", Id = "12518152696"},
{Name = "R15 Reanimated", Id = "4211223236"},
{Name = "Robot", Id = "616095330"},
{Name = "Sneaky", Id = "1132510133"},
{Name = "Sports (Adidas)", Id = "18537392113"},
{Name = "Stylish", Id = "616146177"},
{Name = "Stylized Female", Id = "4708193840"},
{Name = "Superhero", Id = "10921298616"},
{Name = "Toy", Id = "782843345"},
{Name = "Vampire", Id = "1083473930"},
{Name = "Werewolf", Id = "1083178339"},
{Name = "Wicked (Popular)", Id = "92072849924640"},
{Name = "No Boundaries (Walmart)", Id = "18747074203"},
{Name = "Zombie", Id = "616168032"},
},

run = {  
{Name = "Astronaut", Id = "10921039308"},  
{Name = "Adidas Community", Id = "82598234841035"},  
{Name = "Bold", Id = "16738337225"},
{Name = "Bubbly", Id = "10921057244"},
{Name = "Cartoony", Id = "10921076136"},
{Name = "Confident", Id = "1070001516"},
{Name = "Cowboy", Id = "1014401683"},
{Name = "Catwalk Glam", Id = "81024476153754"},
{Name = "Drooling Zombie", Id = "3489173414"},
{Name = "Elder", Id = "10921104374"},
{Name = "Ghost", Id = "616013216"},
{Name = "Knight", Id = "10921121197"},
{Name = "Levitation", Id = "616010382"},
{Name = "Mage", Id = "10921148209"},
{Name = "Ninja", Id = "656118852"},
{Name = "NFL", Id = "117333533048078"},
{Name = "OldSchool", Id = "10921240218"},
{Name = "Patrol", Id = "1150967949"},
{Name = "Pirate", Id = "750783738"},
{Name = "Default Retarget", Id = "102294264237491"},
{Name = "Popstar", Id = "1212980348"},
{Name = "Princess", Id = "941015281"},
{Name = "R6", Id = "12518152696"},
{Name = "R15 Reanimated", Id = "4211220381"},
{Name = "Robot", Id = "10921250460"},
{Name = "Sneaky", Id = "1132494274"},
{Name = "Sports (Adidas)", Id = "18537384940"},
{Name = "Stylish", Id = "10921276116"},
{Name = "Stylized Female", Id = "4708192705"},
{Name = "Superhero", Id = "10921291831"},
{Name = "Toy", Id = "10921306285"},
{Name = "Vampire", Id = "10921320299"},
{Name = "Werewolf", Id = "10921336997"},
{Name = "Wicked (Popular)", Id = "72301599441680"},
{Name = "No Boundaries (Walmart)", Id = "18747070484"},
{Name = "Zombie", Id = "616163682"},
},

jump = {
{Name = "Astronaut", Id = "891627522"},
{Name = "Adidas Community", Id = "656117878"},
{Name = "Bold", Id = "16738336650"},
{Name = "Bubbly", Id = "910016857"},
{Name = "Cartoony", Id = "742637942"},
{Name = "Confident", Id = "1069984524"},
{Name = "Cowboy", Id = "1014394726"},
{Name = "Catwalk Glam", Id = "116936326516985"},
{Name = "Drooling Zombie", Id = "891627522"},
{Name = "Elder", Id = "10921107367"},
{Name = "Ghost", Id = "616008936"},
{Name = "Knight", Id = "910016857"},
{Name = "Levitation", Id = "616008936"},
{Name = "Mage", Id = "10921149743"},
{Name = "Ninja", Id = "656117878"},
{Name = "NFL", Id = "119846112151352"},
{Name = "OldSchool", Id = "10921242013"},
{Name = "Patrol", Id = "1148811837"},
{Name = "Pirate", Id = "750782230"},
{Name = "Default Retarget", Id = "117150377950987"},
{Name = "Popstar", Id = "1212954642"},
{Name = "Princess", Id = "941008832"},
{Name = "R6", Id = "12520880485"},
{Name = "R15 Reanimated", Id = "4211219390"},
{Name = "Robot", Id = "616090535"},
{Name = "Sneaky", Id = "1132489853"},
{Name = "Sports (Adidas)", Id = "18537380791"},
{Name = "Stylish", Id = "616139451"},
{Name = "Stylized Female", Id = "4708188025"},
{Name = "Superhero", Id = "10921294559"},
{Name = "Toy", Id = "10921308158"},
{Name = "Vampire", Id = "1083455352"},
{Name = "Werewolf", Id = "1083218792"},
{Name = "Wicked (Popular)", Id = "104325245285198"},
{Name = "No Boundaries (Walmart)", Id = "18747069148"},
{Name = "Zombie", Id = "616161997"},
},

fall = {
{Name = "Astronaut", Id = "891617961"},
{Name = "Adidas Community", Id = "98600215928904"},
{Name = "Bold", Id = "16738333171"},
{Name = "Bubbly", Id = "910001910"},
{Name = "Cartoony", Id = "742637151"},
{Name = "Confident", Id = "1069973677"},
{Name = "Cowboy", Id = "1014384571"},
{Name = "Catwalk Glam", Id = "92294537340807"},
{Name = "Drooling Zombie", Id = "616157476"},
{Name = "Elder", Id = "10921105765"},
{Name = "Ghost", Id = "10921122579"},
{Name = "Knight", Id = "10921122579"},
{Name = "Levitation", Id = "616005863"},
{Name = "Mage", Id = "707829716"},
{Name = "Ninja", Id = "656115606"},
{Name = "NFL", Id = "129773241321032"},
{Name = "OldSchool", Id = "10921241244"},
{Name = "Patrol", Id = "1148863382"},
{Name = "Pirate", Id = "750780242"},
{Name = "Default Retarget", Id = "110205622518029"},
{Name = "Popstar", Id = "1212900995"},
{Name = "Princess", Id = "941000007"},
{Name = "R6", Id = "12520972571"},
{Name = "R15 Reanimated", Id = "4211216152"},
{Name = "Robot", Id = "616087089"},
{Name = "Sneaky", Id = "1132469004"},
{Name = "Sports (Adidas)", Id = "18537367238"},
{Name = "Stylish", Id = "616134815"},
{Name = "Stylized Female", Id = "4708186162"},
{Name = "Superhero", Id = "10921293373"},
{Name = "Toy", Id = "782846423"},
{Name = "Vampire", Id = "1083443587"},
{Name = "Werewolf", Id = "1083189019"},
{Name = "Wicked (Popular)", Id = "121152442762481"},
{Name = "No Boundaries (Walmart)", Id = "18747062535"},
{Name = "Zombie", Id = "616157476"},
},

climb = {
{Name = "Astronaut", Id = "10921032124"},
{Name = "Adidas Community", Id = "88763136693023"},
{Name = "Bold", Id = "16738332169"},
{Name = "Bubbly", Id = "16738332169"},
{Name = "Cartoony", Id = "742636889"},
{Name = "Confident", Id = "1069946257"},
{Name = "Cowboy", Id = "1014380606"},
{Name = "Catwalk Glam", Id = "119377220967554"},
{Name = "Drooling Zombie", Id = "616156119"},
{Name = "Elder", Id = "845392038"},
{Name = "Ghost", Id = "616003713"},
{Name = "Knight", Id = "10921125160"},
{Name = "Levitation", Id = "10921132092"},
{Name = "Mage", Id = "707826056"},
{Name = "Ninja", Id = "656114359"},
{Name = "NFL", Id = "134630013742019"},
{Name = "OldSchool", Id = "10921229866"},
{Name = "Patrol", Id = "1148811837"},
{Name = "Pirate", Id = "10921032124"},
{Name = "Default Retarget", Id = "10921286911"},
{Name = "Popstar", Id = "1213044953"},
{Name = "Princess", Id = "940996062"},
{Name = "R6", Id = "12520982150"},
{Name = "R15 Reanimated", Id = "4211214992"},
{Name = "Robot", Id = "616086039"},
{Name = "Sneaky", Id = "1132461372"},
{Name = "Sports (Adidas)", Id = "18537363391"},
{Name = "Stylish", Id = "10921271391"},
{Name = "Stylized Female", Id = "4708184253"},
{Name = "Superhero", Id = "10921286911"},
{Name = "Toy", Id = "10921300839"},
{Name = "Vampire", Id = "1083439238"},
{Name = "Werewolf", Id = "10921329322"},
{Name = "Wicked (Popular)", Id = "131326830509784"},
{Name = "No Boundaries (Walmart)", Id = "18747060903"},
{Name = "Zombie", Id = "616156119"},
},

swim = {
{Name = "Astronaut", Id1 = "891663592", Id2 = "891663592"},
{Name = "Adidas Community", Id1 = "109346520324160", Id2 = "133308483266208"},
{Name = "Bold", Id1 = "16738339817", Id2 = "16738339158"},
{Name = "Bubbly", Id1 = "910030921", Id2 = "910028158"},
{Name = "Cartoony", Id1 = "10921079380", Id2 = "10921079380"},
{Name = "Confident", Id1 = "1070012133", Id2 = "1070009914"},
{Name = "CowBoy", Id1 = "1014411816", Id2 = "1014406523"},
{Name = "Catwalk Glam", Id1 = "98854111361360", Id2 = "134591743181628"},
{Name = "Drooling Zombie", Id1 = "18747071682", Id2 = "616165109"},
{Name = "Elder", Id1 = "10921110146", Id2 = "10921108971"},
{Name = "Ghost", Id1 = "10921325443", Id2 = "10921324408"},
{Name = "Knight", Id1 = "10921125935", Id2 = "10921125160"},
{Name = "Levitation", Id1 = "10921325443", Id2 = "10921324408"},
{Name = "Mage", Id1 = "707894699", Id2 = "707876443"},
{Name = "Ninja", Id1 = "656118341", Id2 = "656118341"},
{Name = "NFL", Id1 = "79090109939093", Id2 = "132697394189921"},
{Name = "OldSchool", Id1 = "10921244018", Id2 = "10921243048"},
{Name = "Patrol", Id1 = "1151221899", Id2 = "1151204998"},
{Name = "Pirate", Id1 = "750785176", Id2 = "750784579"},
{Name = "Default Retarget", Id1 = "10921297391", Id2 = "10921295495"},
{Name = "Popstar", Id1 = "1212998578", Id2 = "1212998578"},
{Name = "Princess", Id1 = "941025398", Id2 = "941018893"},
{Name = "R6", Id1 = "12518152696", Id2 = "12518152696"},
{Name = "R15 Reanimated", Id1 = "12518152696", Id2 = "12518152696"},
{Name = "Robot", Id1 = "10921253767", Id2 = "10921253142"},
{Name = "Sneaky", Id1 = "1132506407", Id2 = "1132500520"},
{Name = "Sports (Adidas)", Id1 = "18537387180", Id2 = "18537389531"},
{Name = "Stylish", Id1 = "10921281964", Id2 = "10921281000"},
{Name = "Stylized Female", Id1 = "4708190607", Id2 = "10921281000"},
{Name = "SuperHero", Id1 = "10921297391", Id2 = "10921295495"},
{Name = "Toy", Id1 = "10921310341", Id2 = "10921309319"},
{Name = "Vampire", Id1 = "10921325443", Id2 = "10921324408"},
{Name = "Werewolf", Id1 = "10921341319", Id2 = "10921340419"},
{Name = "Wicked (Popular)", Id1 = "113199415118199", Id2 = "99384245425157"},
{Name = "No Boundaries (Walmart)", Id1 = "18747071682", Id2 = "18747073181"},
{Name = "Zombie", Id1 = "18747071682", Id2 = "616165109"},
},

idle = {
{Name = "Astronaut", Id1 = "891621366", Id2 = "891633237"},
{Name = "Adidas Community", Id1 = "122257458498464", Id2 = "102357151005774"},
{Name = "Bold", Id1 = "16738333868", Id2 = "16738334710"},
{Name = "Bubbly", Id1 = "910004836", Id2 = "910009958"},
{Name = "Cartoony", Id1 = "742637544", Id2 = "742638445"},
{Name = "Confident", Id1 = "1069977950", Id2 = "1069987858"},
{Name = "Cowboy", Id1 = "1014390418", Id2 = "1014398616"},
{Name = "Catwalk Glam", Id1 = "133806214992291", Id2 = "94970088341563"},
{Name = "Drooling Zombie", Id1 = "3489171152", Id2 = "3489171152"},
{Name = "Elder", Id1 = "10921101664", Id2 = "10921102574"},
{Name = "Ghost", Id1 = "616006778", Id2 = "616008087"},
{Name = "Borock", Id1 = "3293641938", Id2 = "3293642554"},
{Name = "Knight", Id1 = "657595757", Id2 = "657568135"},
{Name = "Levitation", Id1 = "616006778", Id2 = "616008087"},
{Name = "Mage", Id1 = "707742142", Id2 = "707855907"},
{Name = "Ninja", Id1 = "656117400", Id2 = "656118341"},
{Name = "NFL", Id1 = "92080889861410", Id2 = "74451233229259"},
{Name = "OldSchool", Id1 = "10921230744", Id2 = "10921232093"},
{Name = "Patrol", Id1 = "1149612882", Id2 = "1150842221"},
{Name = "Pirate", Id1 = "750781874", Id2 = "750782770"},
{Name = "Default Retarget", Id1 = "95884606664820", Id2 = "95884606664820"},
{Name = "Popstar", Id1 = "1212900985", Id2 = "1150842221"},
{Name = "Princess", Id1 = "941003647", Id2 = "941013098"},
{Name = "R6", Id1 = "12521158637", Id2 = "12521162526"},
{Name = "R15 Reanimated", Id1 = "4211217646", Id2 = "4211218409"},
{Name = "Robot", Id1 = "616088211", Id2 = "616089559"},
{Name = "Sneaky", Id1 = "1132473842", Id2 = "1132477671"},
{Name = "Sports (Adidas)", Id1 = "18537376492", Id2 = "18537371272"},
{Name = "Stylish", Id1 = "616136790", Id2 = "616138447"},
{Name = "Stylized Female", Id1 = "4708191566", Id2 = "4708192150"},
{Name = "Superhero", Id1 = "10921288909", Id2 = "10921290167"},
{Name = "Toy", Id1 = "782841498", Id2 = "782845736"},
{Name = "Vampire", Id1 = "1083445855", Id2 = "1083450166"},
{Name = "Werewolf", Id1 = "1083195517", Id2 = "1083214717"},
{Name = "Wicked (Popular)", Id1 = "118832222982049", Id2 = "76049494037641"},
{Name = "No Boundaries (Walmart)", Id1 = "18747067405", Id2 = "18747063918"},
{Name = "Zombie", Id1 = "616158929", Id2 = "616160636"},

{Name = "MrToilet", Id1 = "4417977954", Id2 = "4417978624"},
{Name = "Very Long", Id1 = "18307781743", Id2 = "18307781743"},
{Name = "Sway", Id1 = "560832030", Id2 = "560833564"},
{Name = "Realistic", Id1 = "17172918855", Id2 = "17173014241"},
{Name = "Soldier", Id1 = "3972151362", Id2 = "3972151362"},
{Name = "Udzal", Id1 = "3303162274", Id2 = "3303162549"},
},
}

for i, data in ipairs(animations.walk) do
Section:NewButton(animations.walk[i].Name, "Change your animation", function()
local runData = animations.run[i]
local jumpData = animations.jump[i]
local fallData = animations.fall[i]
local climbData = animations.climb[i]
local swimData = animations.swim[i]
local idleData = animations.idle[i]

if data then Walk(data.Id) end
if runData then Run(runData.Id) end
if jumpData then Jump(jumpData.Id) end
if fallData then fall(fallData.Id) end
if climbData then Climb(climbData.Id) end
if swimData then Swim(swimData.Id1, swimData.Id2) end
if idleData then Idle(idleData.Id1, idleData.Id2) end
end)
end

local Tab = Window:NewTab("Fe Sus")
local Section = Tab:NewSection("Fe Sus")

Section:NewButton("[Fe] Jerk", "Sus", function()
loadstring(game:HttpGet("https://pastebin.com/raw/Zu9zZdGC"))()
end)

Section:NewButton("[Fe] Bang", "Sus", function()
loadstring(game:HttpGet("https://pastebin.com/raw/UKGrSuhg"))()
end)

Section:NewButton("[Fe] Get Banged", "Sus", function()
loadstring(game:HttpGet("https://pastebin.com/raw/xWjReLRN"))()
end)

Section:NewButton("[Fe] Suck", "Sus", function()
loadstring(game:HttpGet("https://pastebin.com/raw/kAzBmV3P"))()
end)

Section:NewButton("[Fe] Get Sucked", "Sus", function()
loadstring(game:HttpGet("https://pastebin.com/raw/CxHY86Ez"))()
end)

local function cleanupAnimations()
for i, track in pairs(tracks) do
if track and track.IsPlaying then
track:Stop()
end
tracks[i] = nil
if connections[i] then
connections[i]:Disconnect()
connections[i] = nil
end
end
end

local animationData = {
	R15 = {	
		{name = "[Fe] Crazy Slash", id = "674871189", loop = true, track = {0.1, 1, 1}},
		{name = "[Fe] Open", id = "582855105", loop = true, track = {0.1, 1, 1}},
		{name = "[Fe] Spinner", id = "754658275", loop = true, track = {0.1, 1, 1}},
		{name = "[Fe] Arms Out", id = "582384156", loop = true, track = {0.1, 1, 1}},
		{name = "[Fe] Float Slash", id = "717879555", loop = true, track = {0.1, 1, 1}},
		{name = "[Fe] Weird Zombie", id = "708553116", loop = true, track = {0.1, 1, 1}},
		{name = "[Fe] Down Slash", id = "746398327", loop = true, track = {0.1, 1, 1}},
		{name = "[Fe] Pull", id = "675025795", loop = true, track = {0.1, 1, 1}},
		{name = "[Fe] Circle Arm", id = "698251653", loop = true, track = {0.1, 1, 1}},
		{name = "[Fe] Bend", id = "696096087", loop = true, track = {0.1, 1, 1}},
		{name = "[Fe] Rotate Slash", id = "675025570", loop = true, track = {0.1, 1, 1}},
		{name = "[Fe] Fling Arms", id = "754656200", loop = true, track = {0.1, 1, 1}},
		{name = "[Fe] Baby Queen - Face Frame", id = "14352340648", track = {0.1, 1, 1}},
		{name = "[Fe] Bored", id = "10713992055", track = {0.1, 1, 1}},
		{name = "[Fe] High-Wave", id = "10714362852", track = {0.1, 1, 1}},
		{name = "[Fe] Baby-Queen-Strut", id = "14352362059", track = {0.1, 1, 1}},
		{name = "[Fe] Curtsy", id = "10714061912", track = {0.1, 1, 1}},
		{name = "[Fe] Greatest", id = "10714349037", track = {0.1, 1, 1}},
		{name = "[Fe] Secret-Handshake-Dance", id = "71243990877913", track = {0.1, 1, 1}},
		{name = "[Fe] Jawny-Stomp", id = "16392075853", track = {0.1, 1, 1}},
		{name = "[Fe] Cuco-Levitate", id = "15698404340", track = {0.1, 1, 1}},
		{name = "[Fe] Baby-Queen-Bouncy-Twirl", id = "14352343065", track = {0.1, 1, 1}},
		{name = "[Fe] Godlike", id = "10714347256", track = {0.1, 1, 1}},
		{name = "[Fe] Sleep", id = "10714360343", track = {0.1, 1, 1}},
		{name = "[Fe] Olivia-Rodrigo-Head-Bop", id = "15517864808", track = {0.1, 1, 1}},
		{name = "[Fe] Haha", id = "10714350889", loop = true, track = {0.1, 1, 1}},
		{name = "[Fe] Happy", id = "10714352626", track = {0.1, 1, 1}},
		{name = "[Fe] HIPMOTION-Amaarae", id = "16572740012", track = {0.1, 1, 1}},
		{name = "[Fe] Yungblud-Happier-Jump", id = "15609995579", track = {0.1, 1, 1}},
		{name = "[Fe] Shy", id = "10714369325", track = {0.1, 1, 1}},
		{name = "[Fe] ylAlo-Yoga-Pose-Lotus-Position", id = "12507085924", track = {0.1, 1, 1}},
		{name = "[Fe] Cower", id = "4940563117", track = {0.1, 1, 1}},
		{name = "[Fe] d4vd-Backflip", id = "15693621070", track = {0.1, 1, 1}},
		{name = "[Fe] Air Guitar", id = "15505454268", track = {0.1, 1, 1}},
		{name = "[Fe] Jumping Wave", id = "10714378156", track = {0.1, 1, 1}},
	},
	R6 = {
	   {name = "[Fe] Throwing Head", id = "35154961", loop = true, track = {0.1, 1, 1}},
{name = "[Fe] Floating Head", id = "121572214", track = {0.1, 1, 1}},
{name = "[Fe] Crouch", id = "182724289", track = {0.1, 1, 1}},
{name = "[Fe] Crouch2", id = "287325678", track = {1, 2, 1}},
{name = "[Fe] Floor Crawl", id = "282574440", track = {0.1, 1, 1}},
{name = "[Fe] Dino Walk", id = "204328711", track = {0.1, 1, 1}},
{name = "[Fe] Jumping Jacks", id = "429681631", track = {0.1, 1, 1}},
{name = "[Fe] Loop Head", id = "35154961", loop = true, track = {0.5, 1, 1e6}},
{name = "[Fe] Hero Jump", id = "184574340", loop = true, track = {0.1, 1, 1}},
{name = "[Fe] Faint", id = "181526230", loop = true, track = {0.1, 1, 1}},
{name = "[Fe] Super Faint", id = "181525546", loop = true, track = {0.1, 0.5, 40}},
{name = "[Fe] Floor Faint", id = "181525546", loop = true, track = {0.1, 1, 2}},
{name = "[Fe] Levitate", id = "313762630", track = {0.1, 1, 1}},
{name = "[Fe] Dab", id = "183412246", loop = true, track = {0.1, 1, 1}},
{name = "[Fe] Spinner", id = "188632011", loop = true, track = {0.1, 1, 2}},
{name = "[Fe] Float Sit", id = "179224234", track = {0.1, 1, 1}},
{name = "[Fe] Moving Dance", id = "429703734", loop = true, track = {0.1, 1, 1}},
{name = "[Fe] Weird Move", id = "215384594", track = {0.1, 1, 2}},
{name = "[Fe] Clone Illusion", id = "215384594", track = {0.5, 1, 1e7}},
{name = "[Fe] Spin Dance", id = "429730430", loop = true, track = {0.1, 1, 1}},
{name = "[Fe] Moon Dance", id = "45834924", loop = true, track = {0.1, 1, 1}},
{name = "[Fe] Full Punch", id = "204062532", loop = true, track = {0.1, 1, 1}},
{name = "[Fe] Spin Dance 2", id = "186934910", loop = true, track = {0.1, 1, 1}},
{name = "[Fe] Bow Down", id = "204292303", loop = true, track = {0.1, 1, 3}},
{name = "[Fe] Sword Slam", id = "204295235", loop = true, track = {0.1, 1, 1}},
{name = "[Fe] Loop Slam", id = "204295235", loop = true, track = {0.1, 1, 1e4}},
{name = "[Fe] Mega Insane", id = "184574340", loop = true, track = {0.1, 0.5, 40}},
{name = "[Fe] Super Punch", id = "126753849", loop = true, track = {0.1, 1, 3}},
{name = "[Fe] Full Swing", id = "218504594", loop = true, track = {0.1, 1, 1}},
{name = "[Fe] Arm Turbine", id = "259438880", track = {0.1, 1, 1e3}},
{name = "[Fe] Barrel Roll", id = "136801964", loop = true, track = {0.1, 1, 1}},
{name = "[Fe] Scared", id = "180612465", loop = true, track = {0.5, 2, 1e10}},
{name = "[Fe] Insane", id = "33796059", track = {0.1, 1, 1e8}},
{name = "[Fe] Arm Detach", id = "33169583", loop = true, track = {0.1, 1, 1e6}},
{name = "[Fe] Sword Slice", id = "35978879", track = {0.1, 1, 1}},
{name = "[Fe] Insane Arms", id = "27432691", loop = true, track = {0.1, 1, 1e4}},
{name = "[Fe] Dance1", id = "182435998", track = {1, 20, 1}},
{name = "[Fe] Dance2", id = "182491277", track = {1, 5, 1}},
{name = "[Fe] Dance3", id = "182491423", track = {1, 5, 1}},
{name = "[Fe] Laugh", id = "129423131", loop = true, track = {1, 20, 1}},
{name = "[Fe] Cheer", id = "129423030", loop = true, track = {1, 20, 1}},
{name = "[Fe] Point", id = "128853357", loop = true, track = {1, 20, 1}},
{name = "[Fe] T", id = "188242481", track = {1, 2, 1}},
{name = "[Fe] Arms Up", id = "187951261", track = {1, 2, 1}},
{name = "[Fe] Backpack Head", id = "68339848", loop = true, track = {1, 2, 1}},
{name = "[Fe] Driving", id = "168138731", track = {1, 2, 1}},
{name = "[Fe] Bang", id = "148840371", track = {1, 2, 1}},
{name = "[Fe] Right Head Position", id = "88016955", track = {1, 2, 1}},
{name = "[Fe] Flexing", id = "248263260", track = {1, 2, 1}},
	}
}

local Tab = Window:NewTab("Setting")
local Section = Tab:NewSection("Setting")

Section:NewButton("Stop All Animations", "Stops every playing animation.", function()
cleanupAnimations()
end)

Section:NewTextBox("Emote Id", "Place the id to play the emote", function(txt)
if string.find(txt, "http://www.roblox.com") then
id = string.gsub(txt, "http://www.roblox.com/asset/?id=", "rbxassetid://")
print(id)
elseif string.find(txt, "rbxassetid://") then
	id = txt
	print(id)
else
id = "rbxassetid://" .. txt
print(id)
end
end)

Section:NewToggle("Emote", "Toggle your id emote", function(state)
if state and not isPlaying then
isPlaying = true
local success, result = pcall(function()
local animation = Instance.new("Animation")
animation.AnimationId = id
return animator:LoadAnimation(animation)
end)
if success then
animTrack = result
animTrack:Play()
else
warn("Animation failed to load:", result)
isPlaying = false
end
elseif not state and isPlaying and animTrack then
animTrack:Stop()
isPlaying = false
end
end)

Section:NewTextBox("Speed", "Change your animation speed", function(txt)
speed = tostring(txt)
for i, track in pairs(tracks) do
if track and track.IsPlaying then
track:AdjustSpeed(speed)
end
end
end)

local Tab = Window:NewTab("R15")
local Section = Tab:NewSection("R15")

Section:NewButton("Stop All Animations", "Stops every playing animation.", function()
cleanupAnimations()
end)

for i, data in ipairs(animationData.R15) do
Section:NewToggle(data.name, "Alternate Emote.", function(state)
local character = player.Character or player.CharacterAdded:Wait()
local humanoid = character:FindFirstChildOfClass("Humanoid")
if not humanoid then return end
cleanupAnimations()
if not tracks[i] then
local anim = Instance.new("Animation")
anim.AnimationId = "rbxassetid://" .. data.id
tracks[i] = humanoid:LoadAnimation(anim)
end
if state then
if data.loop then
connections[i] = RunService.Heartbeat:Connect(function()
if not tracks[i].IsPlaying then
tracks[i]:Play(unpack(data.track))
wait()
for i, track in pairs(tracks) do
if track and track.IsPlaying then
track:AdjustSpeed(speed)
end
end
end
end)
end
tracks[i]:Play(unpack(data.track))
wait()
for i, track in pairs(tracks) do
if track and track.IsPlaying then
track:AdjustSpeed(speed)
end
end
else
if tracks[i] then
tracks[i]:Stop()
end
if connections[i] then
connections[i]:Disconnect()
connections[i] = nil
end
end
end)
end

local Tab = Window:NewTab("R6")
local Section = Tab:NewSection("R6")

Section:NewButton("Stop All Animations", "Stops every playing animation.", function()
cleanupAnimations()
end)

for i, data in ipairs(animationData.R6) do
Section:NewToggle(data.name, "Alternate Emote.", function(state)
local character = player.Character or player.CharacterAdded:Wait()
local humanoid = character:FindFirstChildOfClass("Humanoid")
if not humanoid then return end
cleanupAnimations()
if not tracks[i] then
local anim = Instance.new("Animation")
anim.AnimationId = "rbxassetid://" .. data.id
tracks[i] = humanoid:LoadAnimation(anim)
end
if state then
if data.loop then
connections[i] = RunService.Heartbeat:Connect(function()
if not tracks[i].IsPlaying then
tracks[i]:Play(unpack(data.track))
wait()
for i, track in pairs(tracks) do
if track and track.IsPlaying then
track:AdjustSpeed(speed)
end
end
end
end)
end
tracks[i]:Play(unpack(data.track))
wait()
for i, track in pairs(tracks) do
if track and track.IsPlaying then
track:AdjustSpeed(speed)
end
end
else
if tracks[i] then
tracks[i]:Stop()
end
if connections[i] then
connections[i]:Disconnect()
connections[i] = nil
end
end
end)
end