local pos = game.Players.LocalPlayer.Character.HumanoidRootPart.Position
local po = tostring(pos)
local S = Instance.new("ScreenGui")
S.Parent = game.CoreGui
S.Name = "Pos"

local F = Instance.new("Frame")
F.Parent = S
F.Active = true
F.Size = UDim2.new(0, 230, 0, 130)
F.Position = UDim2.new(0, 230, 0, 100)
F.BackgroundColor3 = Color3.fromRGB(0, 200, 255)
F.BorderSizePixel = 3
F.Draggable = true
F.BorderColor3 = Color3.fromRGB(0, 0, 0)

local T = Instance.new("TextButton")
T.Parent = F
T.Size = UDim2.new(0, 180, 0, 50)
T.Position = UDim2.new(0, 23, 0, 15)
T.BackgroundColor3 = Color3.fromRGB(255, 200, 255)
T.BorderSizePixel = 2
T.BorderColor3 = Color3.fromRGB(0, 0, 0)
T.TextScaled = true
T.Font = Enum.Font.SciFi
T.Text = po

local B = Instance.new("TextButton")
B.Parent = F
B.Size = UDim2.new(0, 48, 0, 30)
B.Position = UDim2.new(0, 23, 0, 85)
B.BackgroundColor3 = Color3.fromRGB(255, 200, 255)
B.BorderSizePixel = 2
B.BorderColor3 = Color3.fromRGB(0, 0, 0)
B.TextScaled = false
B.Text = "Find"
B.TextScaled = true
B.Font = Enum.Font.SciFi
B.MouseButton1Click:Connect(function()
local pos = game.Players.LocalPlayer.Character.HumanoidRootPart.Position
local po = tostring(pos)
T.Text = po
end)

local B2 = Instance.new("TextButton")
B2.Parent = F
B2.TextScaled = true
B2.Font = Enum.Font.SciFi
B2.Size = UDim2.new(0, 48, 0, 30)
B2.Position = UDim2.new(0, 155, 0, 85)
B2.BackgroundColor3 = Color3.fromRGB(255, 200, 255)
B2.BorderSizePixel = 2
B2.BorderColor3 = Color3.fromRGB(0, 0, 0)
B2.Text = "Copy"
B2.MouseButton1Click:Connect(function()
setclipboard(T.Text)
end)

local B3 = Instance.new("TextButton")
B3.Parent = F
B3.Font = Enum.Font.ArimoBold
B3.Size = UDim2.new(0, 48, 0, 30)
B3.Position = UDim2.new(0, 190, 0, -5)
B3.Text = "X"
B3.TextSize = 15
B3.BackgroundTransparency = 1
B3.MouseButton1Click:Connect(function()
S:Destroy()
end)