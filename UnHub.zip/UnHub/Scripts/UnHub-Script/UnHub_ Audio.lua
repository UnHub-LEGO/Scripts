local Library = loadstring(game:HttpGet("https://raw.githubusercontent.com/NICKISBAD/Nick-s-Modded-KAVO-Lib/main/Nick'sModdedKavoLib.lua"))()
local Window = Library.CreateLib("Un Hub: Audio | Made By LE_GO89", "DarkTheme")

if not game.Workspace:FindFirstChild("Audio") then
    local Audio = Instance.new("Sound")
    Audio.Volume = 1
    Audio.Name = "Audio"
    Audio.Parent = game.Workspace
end

local function PlayAudio(Id)
    if Audio.IsPlaying then
        Audio:Stop()
    end

    local success, err = pcall(function()
        Audio.SoundId = "rbxassetid://" .. Id
        Audio:Play()
    end)
end

local MusicTab = Window:NewTab("Music")
local MusicSection = MusicTab:NewSection("Music Controls")

local Music = {
    {Id = 1840684529, Name = "Cool Vibes"},
    {Id = 1846458016, Name = "No More"},
    {Id = 1838457617, Name = "Clair De Lune"},
    {Id = 1846575559, Name = "Diamonds"},
    {Id = 1843404009, Name = "Happy Song"},
    {Id = 1846911135, Name = "Really Fast"},
    {Id = 1841476350, Name = "Happy-Go-Lively"},
    {Id = 1837560230, Name = "Classes Chase"},
    {Id = 9040296745, Name = "Desert Trails"},
    {Id = 1845554017, Name = "Uptown"},
    {Id = 1848354536, Name = "Relaxed Scene"},
    {Id = 1841647093, Name = "Life In Elevator"},
    {Id = 1837879082, Name = "Paradise Falls"},
    {Id = 142376088, Name = "It Raining Tanos"},
    {Id = 5409360995, Name = "Dion Timmer"},
    {Id = 1848028342, Name = "Nocturne Opus 9 C"},
    {Id = 9047876673, Name = "Happy Adventure"},
    {Id = 9038254260, Name = "Fight though Adversity"},
}

for _, data in ipairs(Music) do
    MusicSection:NewToggle(data.Name, "Play " .. data.Name, function(state)
        if state then
            PlayAudio(data.Id)
        else
            Audio:Stop()
        end
    end)
end

local PhonkTab = Window:NewTab("Phonk")
local PhonkSection = PhonkTab:NewSection("Phonk Tracks")

local Phonk = {
    {Id = 122863102226559, Name = "SKIBIDI TOILET PHONK"},
    {Id = 14145620056, Name = "The Final Phonk"},
    {Id = 103409297553965, Name = "FUNK FESTA"},
    {Id = 14145623221, Name = "No Lights"},
    {Id = 71123357599630, Name = "Beauty"},
    {Id = 120889371113999, Name = "pac man phonk"},
    {Id = 81508660514757, Name = "Phonky Maxwell"},
    {Id = 110856257452699, Name = "Spooky Phonk"},
    {Id = 129098116998483, Name = "TOMA FUNK PHONK"},
    {Id = 136932193331774, Name = "Roblox Phonk"},
    {Id = 120423453615283, Name = "Bravery"},
    {Id = 14145625078, Name = "Distorted"},
    {Id = 135667903253566, Name = "Brazilian Phonk"},
    {Id = 139161205970637, Name = "Dress To Impress Theme"},
    {Id = 14145622615, Name = "Black Seed"},
    {Id = 75057905314659, Name = "Sigma Phonk"},
    {Id = 85721148897646, Name = "TOKYO DRIFT PHONK"},
    {Id = 73432582424998, Name = "Breakcore Phonky"},
    {Id = 93202214051700, Name = "Hardcore Drift Phonk"},
    {Id = 84364989216881, Name = "King Of The Kill"},
    {Id = 101326109963284, Name = "F-Phonk"},
}

for _, data in ipairs(Phonk) do
    PhonkSection:NewToggle(data.Name, "Play " .. data.Name, function(state)
        if state then
            PlayAudio(data.Id)
        else
            Audio:Stop()
        end
    end)
end

local SettingTab = Window:NewTab("Setting")
local SettingSection = SettingTab:NewSection("Setting Controls")

SettingSection:NewTextBox("Load Sound", "Load the sound id", function(txt)
    if Audio.IsPlaying then
        Audio:Stop()
    end
    if string.find(txt, "http://www.roblox.com/asset/?id=") then
        Audio.SoundId = string.gsub(txt, "http://www.roblox.com/asset/?id=", "rbxassetid://")
    elseif string.find(txt, "rbxassetid://") then
    	Audio.SoundId = txt
    else
        Audio.SoundId = "rbxassetid://" .. txt
    end
end)

SettingSection:NewToggle("Play", "Play the sound id", function(state)
    if state then
        Audio:Play()
    else
        Audio:Stop()
    end
end)

SettingSection:NewToggle("Loop", "Adjust music loop", function(state)
    if state then
        Audio.Loop = true
    else
        Audio.Loop = false
    end
end)

SettingSection:NewTextBox("Time", "Adjust music time", function(txt)
    Audio.TimePosition = tonumber(txt)
end)

SettingSection:NewTextBox("Volume", "Adjust music volume", function(txt)
    Audio.Volume = tonumber(txt)
end)

SettingSection:NewTextBox("Speed", "Adjust music speed", function(txt)
    Audio.PlaybackSpeed = tonumber(txt)
end)

SettingSection:NewButton("Stop Music", "Stops current playing music", function()
    Audio:Stop()
end)