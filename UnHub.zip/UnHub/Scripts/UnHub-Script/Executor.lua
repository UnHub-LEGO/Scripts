local TextService = game:GetService("TextService")

local screenGui = Instance.new("ScreenGui", game.CoreGui)
screenGui.Name = "ScriptEditorGUI"
screenGui.ResetOnSpawn = false

local mainFrame = Instance.new("Frame", screenGui)
mainFrame.Size = UDim2.new(0, 600, 0, 400)
mainFrame.Position = UDim2.new(0.5, -300, 0.5, 0)
mainFrame.BackgroundColor3 = Color3.fromRGB(10, 10, 10)
mainFrame.BorderSizePixel = 0
mainFrame.Active = true
mainFrame.Draggable = true

local UICorner = Instance.new("UICorner", mainFrame)

local Title = Instance.new("TextLabel", mainFrame)
Title.Size = UDim2.new(0, 100, 0, 40)
Title.AnchorPoint = Vector2.new(0.5, 0)
Title.Position = UDim2.new(0.5, 0, 0, 0)
Title.BackgroundTransparency = 1
Title.Text = "Executor By LE_GO89"
Title.TextColor3 = Color3.new(1, 1, 1)
Title.Font = Enum.Font.SourceSansBold
Title.TextSize = 20

local Close = Instance.new("TextButton", mainFrame)
Close.Size = UDim2.new(0, 25, 0, 25)
Close.AnchorPoint = Vector2.new(0.5, 0)
Close.Position = UDim2.new(0.965, 0, 0, 5)
Close.BackgroundTransparency = 1
Close.Text = "x"
Close.TextColor3 = Color3.new(1, 1, 1)
Close.Font = Enum.Font.SourceSansBold
Close.TextSize = 25

local OC = Instance.new("TextButton", mainFrame)
OC.Size = UDim2.new(0, 25, 0, 25)
OC.AnchorPoint = Vector2.new(0.5, 0)
OC.Position = UDim2.new(0.9, 0, 0, 5)
OC.BackgroundTransparency = 1
OC.Text = "-"
OC.TextColor3 = Color3.new(1, 1, 1)
OC.Font = Enum.Font.SourceSansBold
OC.TextSize = 25

local scrollFrame = Instance.new("ScrollingFrame", mainFrame)
scrollFrame.Size = UDim2.new(1, -20, 1, -60)
scrollFrame.Position = UDim2.new(0, 10, 0, 40)
scrollFrame.BackgroundTransparency = 0.1
scrollFrame.BorderSizePixel = 0
scrollFrame.BackgroundColor3 = Color3.fromRGB(36, 36, 36)
scrollFrame.ScrollBarThickness = 6
scrollFrame.ScrollingDirection = Enum.ScrollingDirection.XY
scrollFrame.HorizontalScrollBarInset = Enum.ScrollBarInset.Always
scrollFrame.VerticalScrollBarInset = Enum.ScrollBarInset.Always

local highlightLabel = Instance.new("TextLabel", scrollFrame)
highlightLabel.BackgroundTransparency = 1
highlightLabel.TextXAlignment = Enum.TextXAlignment.Left
highlightLabel.TextYAlignment = Enum.TextYAlignment.Top
highlightLabel.TextColor3 = Color3.fromRGB(0, 255, 255)
highlightLabel.Font = Enum.Font.Code
highlightLabel.TextSize = 16
highlightLabel.RichText = true
highlightLabel.TextWrapped = false
highlightLabel.ClipsDescendants = false
highlightLabel.Text = ""

local editorBox = Instance.new("TextBox", scrollFrame)
editorBox.BackgroundTransparency = 1
editorBox.TextTransparency = 1
editorBox.Size = UDim2.new(1, 0, 1, 0)
editorBox.TextColor3 = Color3.new(0, 0, 0)
editorBox.TextXAlignment = Enum.TextXAlignment.Left
editorBox.TextYAlignment = Enum.TextYAlignment.Top
editorBox.Font = Enum.Font.Code
editorBox.TextSize = 16
editorBox.ClearTextOnFocus = false
editorBox.MultiLine = true
editorBox.TextWrapped = false
editorBox.Text = ""

local Execute = Instance.new("TextButton", mainFrame)
Execute.Size = UDim2.new(0, 100, 0, 40)
Execute.Position = UDim2.new(1, -110, 1, -50)
Execute.BackgroundColor3 = Color3.fromRGB(0, 170, 0)
Execute.Text = "Execute"
Execute.TextColor3 = Color3.new(1, 1, 1)
Execute.Font = Enum.Font.SourceSansBold
Execute.TextSize = 20

local Clear = Instance.new("TextButton", mainFrame)
Clear.Size = UDim2.new(0, 100, 0, 40)
Clear.Position = UDim2.new(1, -220, 1, -50)
Clear.BackgroundColor3 = Color3.fromRGB(0, 170, 0)
Clear.Text = "Clear"
Clear.TextColor3 = Color3.new(1, 1, 1)
Clear.Font = Enum.Font.SourceSansBold
Clear.TextSize = 20

local keywords = {
	["local"] = "#B800B3", ["function"] = "#B800B3", ["end"] = "#B800B3",
	["if"] = "#B800B3", ["then"] = "#B800B3", ["else"] = "#B800B3",
	["for"] = "#B800B3", ["in"] = "#B800B3", ["do"] = "#B800B3",
	["while"] = "#B800B3", ["return"] = "#B800B3", ["nil"] = "#B800B3",
	["true"] = "#4A00FF", ["false"] = "#FF0000", ["gsub"] = "#2241FF", ["format"] = "#2241FF",
	["max"] = "#2241FF", ["huge"] = "#2241FF", ["string"] = "#A2FD99", ["math"] = "#A2FD99",
	["loadstring"] = "#2241FF", ["pcall"] = "#2241FF"
}

local function escapeRichText(str)
	str = str:gsub("&", "&amp;")
	str = str:gsub("<", "&lt;")
	str = str:gsub(">", "&gt;")
	return str
end

local function highlightSyntax(text)
	text = escapeRichText(text)
	text = text:gsub("([\"'])(.-)%1", function(q, s)
		return string.format('<font color="#C4FE4A">%s%s%s</font>', q, s, q)
	end)
	text = text:gsub("(%f[%a_])([%a_][%w_]*)(%f[^%w_])", function(_, word, _)
		local color = keywords[word]
		if color then
			return string.format('<font color="%s">%s</font>', color, word)
		end
		return word
	end)
	text = text:gsub("\n", "&#13;\n")
	return text
end

local function updateHighlight()
	highlightLabel.Text = highlightSyntax(editorBox.Text)
end

local function updateCanvasSize()
	local text = editorBox.Text
	local lines = text:split("\n")
	local maxWidth = 0
	for _, line in ipairs(lines) do
		local size = TextService:GetTextSize(line, editorBox.TextSize, editorBox.Font, Vector2.new(math.huge, math.huge))
		if size.X > maxWidth then maxWidth = size.X end
	end
	local totalHeight = #lines * TextService:GetTextSize("A", editorBox.TextSize, editorBox.Font, Vector2.new(1000, 1000)).Y + 10
	local totalWidth = maxWidth + 20
	editorBox.Size = UDim2.new(1, totalWidth, 1, totalHeight)
	highlightLabel.Size = editorBox.Size
	scrollFrame.CanvasSize = UDim2.new(0, totalWidth, 0, totalHeight)
end

scrollFrame:GetPropertyChangedSignal("CanvasPosition"):Connect(function()
	local offset = -scrollFrame.CanvasPosition
	editorBox.Position = UDim2.new(0, offset.X, 0, offset.Y)
	highlightLabel.Position = UDim2.new(0, offset.X, 0, offset.Y)
end)

editorBox:GetPropertyChangedSignal("Text"):Connect(function()
	updateHighlight()
	updateCanvasSize()
end)

scrollFrame:GetPropertyChangedSignal("AbsoluteSize"):Connect(updateCanvasSize)

editorBox.Focused:Connect(function()
	editorBox.TextTransparency = 0
	editorBox.TextColor3 = Color3.new(1, 1, 1)
	highlightLabel.TextTransparency = 1
end)

editorBox.FocusLost:Connect(function()
	editorBox.TextTransparency = 1
	editorBox.TextColor3 = Color3.new(0, 0, 0)
	highlightLabel.TextTransparency = 0
end)

Execute.MouseButton1Click:Connect(function()
	local code = editorBox.Text
	local f, err = loadstring(code)
	if f then
		local ok, runtimeErr = pcall(f)
		if not ok then
			warn("Runtime error:", runtimeErr)
		end
	else
		warn("Syntax error:", err)
	end
end)

Clear.MouseButton1Click:Connect(function()
    editorBox.Text = ""
    highlightLabel.Text = ""
end)

Close.MouseButton1Click:Connect(function()
    screenGui:Destroy()
end)
local T = false
OC.MouseButton1Click:Connect(function()
T = not T
if T then
    Clear.Visible = false
    Execute.Visible = false
    scrollFrame.Visible = false
    mainFrame.Size = UDim2.new(0, 600, 0, 40)
    OC.Text = "+"
else
    Clear.Visible = true
    Execute.Visible = true
    scrollFrame.Visible = true
    mainFrame.Size = UDim2.new(0, 600, 0, 400)
    OC.Text = "-"
end
end)

updateHighlight()
updateCanvasSize()