local humanoid = game.Players.LocalPlayer.Character:WaitForChild("Humanoid")
if humanoid.RigType == Enum.HumanoidRigType.R6 then
   local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")
local LocalPlayer = Players.LocalPlayer
local UserInputService = game:GetService("UserInputService")

local ScreenGui = Instance.new("ScreenGui")
ScreenGui.Parent = game.CoreGui
ScreenGui.Name = "ModernGUI"

local MainFrame = Instance.new("Frame")
MainFrame.Parent = ScreenGui
MainFrame.Size = UDim2.new(0, 230, 0, 130)
MainFrame.Position = UDim2.new(0, 230, 0, 100)
MainFrame.BackgroundColor3 = Color3.fromRGB(0, 200, 255)
MainFrame.Active = true
MainFrame.Draggable = true
MainFrame.BorderSizePixel = 3
MainFrame.BorderColor3 = Color3.fromRGB(0, 0, 0)

local TitleBar = Instance.new("Frame")
TitleBar.Parent = MainFrame
TitleBar.Size = UDim2.new(1, 0, 0, 25)
TitleBar.BackgroundColor3 = Color3.fromRGB(0, 200, 255)
TitleBar.BorderSizePixel = 0

local TitleLabel = Instance.new("TextLabel")
TitleLabel.Parent = TitleBar
TitleLabel.Size = UDim2.new(0, 50, 1, 0)
TitleLabel.Position = UDim2.new(0, 30, 0, 0)
TitleLabel.Text = "Get Banged"
TitleLabel.TextColor3 = Color3.fromRGB(0, 0, 0)
TitleLabel.BackgroundTransparency = 1
TitleLabel.TextSize = 14

local CloseButton = Instance.new("TextButton")
CloseButton.Parent = TitleBar
CloseButton.Size = UDim2.new(0, 25, 1, 0)
CloseButton.Position = UDim2.new(1, -25, 0, 0)
CloseButton.Text = "X"
CloseButton.TextColor3 = Color3.fromRGB(0, 0, 0)
CloseButton.BackgroundTransparency = 1
CloseButton.BorderSizePixel = 0
CloseButton.MouseButton1Click:Connect(function()
    ScreenGui:Destroy()
end)

local TargetTextBox = Instance.new("TextBox")
TargetTextBox.Parent = MainFrame
TargetTextBox.Size = UDim2.new(0.9, 0, 0, 30)
TargetTextBox.Position = UDim2.new(0.05, 0, 0.3, 0)
TargetTextBox.PlaceholderText = "Enter target name"
TargetTextBox.Text = ""
TargetTextBox.TextColor3 = Color3.fromRGB(0, 0, 0)
TargetTextBox.BackgroundColor3 = Color3.fromRGB(255, 200, 255)
TargetTextBox.BorderSizePixel = 2
TargetTextBox.BorderColor3 = Color3.fromRGB(0, 0, 0)

local ToggleButton = Instance.new("TextButton")
ToggleButton.Parent = MainFrame
ToggleButton.TextScaled = true
ToggleButton.Font = Enum.Font.SciFi
ToggleButton.Size = UDim2.new(0, 48, 0, 30)
ToggleButton.Position = UDim2.new(0, 90, 0, 85)
ToggleButton.BackgroundColor3 = Color3.fromRGB(255, 200, 255)
ToggleButton.BorderSizePixel = 2
ToggleButton.BorderColor3 = Color3.fromRGB(0, 0, 0)
ToggleButton.Text = "Start"

local following = false
local targetPlayer = nil
local animationId = "189854234"
local activeAnimation

ToggleButton.MouseButton1Click:Connect(function()
    if not following then
        local targetName = TargetTextBox.Text:lower()
        targetPlayer = nil
        
        for _, player in pairs(Players:GetPlayers()) do
            if player.Name:lower():find(targetName) or player.DisplayName:lower():find(targetName) then
                targetPlayer = player
                break
            end
        end
        
        if targetPlayer and targetPlayer.Character then
            following = true
            ToggleButton.Text = "Stop"
            
            local humanoid = LocalPlayer.Character:FindFirstChildOfClass("Humanoid")
            if humanoid then
                local animation = Instance.new("Animation")
                animation.AnimationId = "rbxassetid://" .. animationId
                activeAnimation = humanoid:LoadAnimation(animation)
                activeAnimation:Play()
            end

            coroutine.wrap(function()
                local lastPosition = nil
                while following do
                    local targetCharacter = targetPlayer.Character
                    if targetCharacter and targetCharacter:FindFirstChild("HumanoidRootPart") then
                        local targetHRP = targetCharacter.HumanoidRootPart
                        local forwardCFrame = targetHRP.CFrame * CFrame.new(0, 0, -2.5)
                        local backwardCFrame = targetHRP.CFrame * CFrame.new(0, 0, -1.3)

                        local tweenForward = TweenService:Create(
                            LocalPlayer.Character:FindFirstChild("HumanoidRootPart"),
                            TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out),
                            {CFrame = forwardCFrame}
                        )
                        tweenForward:Play()
                        tweenForward.Completed:Wait()

                        local tweenBackward = TweenService:Create(
                            LocalPlayer.Character:FindFirstChild("HumanoidRootPart"),
                            TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out),
                            {CFrame = backwardCFrame}
                        )
                        tweenBackward:Play()
                        tweenBackward.Completed:Wait()
                    else
                        following = false
                        ToggleButton.Text = "Start"
                        break
                    end
                end
            end)()
        end
    else
        following = false
        ToggleButton.Text = "Start"
        
        if activeAnimation then
            activeAnimation:Stop()
            activeAnimation = nil
        end
    end
end)
elseif humanoid.RigType == Enum.HumanoidRigType.R15 then
   local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")
local LocalPlayer = Players.LocalPlayer
local UserInputService = game:GetService("UserInputService")

local ScreenGui = Instance.new("ScreenGui")
ScreenGui.Parent = game.CoreGui
ScreenGui.Name = "ModernGUI"

local MainFrame = Instance.new("Frame")
MainFrame.Parent = ScreenGui
MainFrame.Size = UDim2.new(0, 230, 0, 130)
MainFrame.Position = UDim2.new(0, 230, 0, 100)
MainFrame.BackgroundColor3 = Color3.fromRGB(0, 200, 255)
MainFrame.Active = true
MainFrame.Draggable = true
MainFrame.BorderSizePixel = 3
MainFrame.BorderColor3 = Color3.fromRGB(0, 0, 0)

local TitleBar = Instance.new("Frame")
TitleBar.Parent = MainFrame
TitleBar.Size = UDim2.new(1, 0, 0, 25)
TitleBar.BackgroundColor3 = Color3.fromRGB(0, 200, 255)
TitleBar.BorderSizePixel = 0

local TitleLabel = Instance.new("TextLabel")
TitleLabel.Parent = TitleBar
TitleLabel.Size = UDim2.new(0, 50, 1, 0)
TitleLabel.Position = UDim2.new(0, 30, 0, 0)
TitleLabel.Text = "Get Banged"
TitleLabel.TextColor3 = Color3.fromRGB(0, 0, 0)
TitleLabel.BackgroundTransparency = 1
TitleLabel.TextSize = 14

local CloseButton = Instance.new("TextButton")
CloseButton.Parent = TitleBar
CloseButton.Size = UDim2.new(0, 25, 1, 0)
CloseButton.Position = UDim2.new(1, -25, 0, 0)
CloseButton.Text = "X"
CloseButton.TextColor3 = Color3.fromRGB(0, 0, 0)
CloseButton.BackgroundTransparency = 1
CloseButton.BorderSizePixel = 0
CloseButton.MouseButton1Click:Connect(function()
    ScreenGui:Destroy()
end)

local TargetTextBox = Instance.new("TextBox")
TargetTextBox.Parent = MainFrame
TargetTextBox.Size = UDim2.new(0.9, 0, 0, 30)
TargetTextBox.Position = UDim2.new(0.05, 0, 0.3, 0)
TargetTextBox.PlaceholderText = "Enter target name"
TargetTextBox.Text = ""
TargetTextBox.TextColor3 = Color3.fromRGB(0, 0, 0)
TargetTextBox.BackgroundColor3 = Color3.fromRGB(255, 200, 255)
TargetTextBox.BorderSizePixel = 2
TargetTextBox.BorderColor3 = Color3.fromRGB(0, 0, 0)

local ToggleButton = Instance.new("TextButton")
ToggleButton.Parent = MainFrame
ToggleButton.TextScaled = true
ToggleButton.Font = Enum.Font.SciFi
ToggleButton.Size = UDim2.new(0, 48, 0, 30)
ToggleButton.Position = UDim2.new(0, 90, 0, 85)
ToggleButton.BackgroundColor3 = Color3.fromRGB(255, 200, 255)
ToggleButton.BorderSizePixel = 2
ToggleButton.BorderColor3 = Color3.fromRGB(0, 0, 0)
ToggleButton.Text = "Start"

local following = false
local targetPlayer = nil
local animationId = "10714360343"
local activeAnimation

ToggleButton.MouseButton1Click:Connect(function()
    if not following then
        local targetName = TargetTextBox.Text:lower()
        targetPlayer = nil
        
        for _, player in pairs(Players:GetPlayers()) do
            if player.Name:lower():find(targetName) or player.DisplayName:lower():find(targetName) then
                targetPlayer = player
                break
            end
        end
        
        if targetPlayer and targetPlayer.Character then
            following = true
            ToggleButton.Text = "Stop"
            
            local humanoid = LocalPlayer.Character:FindFirstChildOfClass("Humanoid")
            if humanoid then
                local animation = Instance.new("Animation")
                animation.AnimationId = "rbxassetid://" .. animationId
                activeAnimation = humanoid:LoadAnimation(animation)
                activeAnimation:Play()
            end

            coroutine.wrap(function()
                local lastPosition = nil
                while following do
                    local targetCharacter = targetPlayer.Character
                    if targetCharacter and targetCharacter.PrimaryPart then
                        local forwardCFrame = targetCharacter.PrimaryPart.CFrame * CFrame.new(0, 0, -1.5)
                        local backwardCFrame = targetCharacter.PrimaryPart.CFrame * CFrame.new(0, 0, -1.1)

                        local tweenForward = TweenService:Create(
                            LocalPlayer.Character.PrimaryPart,
                            TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out),
                            {CFrame = forwardCFrame}
                        )
                        tweenForward:Play()
                        tweenForward.Completed:Wait()

                        local tweenBackward = TweenService:Create(
                            LocalPlayer.Character.PrimaryPart,
                            TweenInfo.new(0.15, Enum.EasingStyle.Linear, Enum.EasingDirection.Out),
                            {CFrame = backwardCFrame}
                        )
                        tweenBackward:Play()
                        tweenBackward.Completed:Wait()
                    else
                        following = false
                        ToggleButton.Text = "Start"
                        break
                    end
                end
            end)()
        end
    else
        following = false
        ToggleButton.Text = "Start"
        
        if activeAnimation then
            activeAnimation:Stop()
            activeAnimation = nil
        end
    end
end)
end
